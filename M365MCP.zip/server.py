from __future__ import annotations

import os
import sys
import time
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional
import re

import httpx
import dotenv
import json

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings  

# -----------------------------
# Logging
# -----------------------------
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    stream=sys.stderr,
    format="%(asctime)s %(levelname)s %(name)s - %(message)s",
)
logger = logging.getLogger("m365_mcp")

dotenv.load_dotenv()
 
# -----------------------------
# Graph Service Communications API endpoints 
# -----------------------------
GRAPH_BASE = "https://graph.microsoft.com/v1.0/admin/serviceAnnouncement"
MESSAGES_URL = f"{GRAPH_BASE}/messages"
HEALTH_OVERVIEWS_URL = f"{GRAPH_BASE}/healthOverviews"
ISSUES_URL = f"{GRAPH_BASE}/issues"

TOKEN_SCOPE = "https://graph.microsoft.com/.default"
DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)
DEFAULT_UA = "m365-messagecentre-mcp/1.0"

_token: str = ""
_token_expiry: float = 0.0


def _require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(
            f"Missing environment variable: {name}. "
            f"Set it in Azure App Service Environment variables (App settings)."
        )
    return value


def _odata_escape(value: str) -> str:
    return value.replace("'", "''")


def _utc_iso_z(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


async def _get_access_token(client: httpx.AsyncClient) -> str:
    global _token, _token_expiry

    if _token and time.time() < (_token_expiry - 60):
        return _token

    tenant_id = _require_env("TENANT_ID")
    client_id = _require_env("CLIENT_ID")
    client_secret = _require_env("CLIENT_SECRET")

    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    data = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": TOKEN_SCOPE,
    }

    resp = await client.post(token_url, data=data)
    resp.raise_for_status()

    payload = resp.json()
    _token = payload["access_token"]
    _token_expiry = time.time() + int(payload.get("expires_in", 3599))
    return _token


async def _graph_get(url: str, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT, headers={"User-Agent": DEFAULT_UA}) as client:
        token = await _get_access_token(client)
        headers = {"Authorization": f"Bearer {token}"}
        resp = await client.get(url, headers=headers, params=params)
        resp.raise_for_status()
        return resp.json()
    
async def _graph_get_all_pages(
    url: str,
    params: Optional[dict[str, Any]] = None,
    max_pages: int = 50,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []

    async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT, headers={"User-Agent": DEFAULT_UA}) as client:
        token = await _get_access_token(client)
        headers = {
            "Authorization": f"Bearer {token}",
            "Prefer": "odata.maxpagesize=1000",  # supported on messages endpoint
        }

        next_url = url
        next_params = params

        for _ in range(max_pages):
            resp = await client.get(next_url, headers=headers, params=next_params)
            resp.raise_for_status()
            payload = resp.json()

            results.extend(payload.get("value", []))

            next_url = payload.get("@odata.nextLink")
            if not next_url:
                break

            # nextLink already contains the query
            next_params = None

    return results


def _format_list(title: str, items: list[str]) -> str:
    if not items:
        return f"{title}\n\nNo results."
    return f"{title}\n\n" + "\n".join(items)

def _strip_html(text: str) -> str:
    if not text:
        return ""
    # super light HTML strip (good enough for Graph post bodies)
    return re.sub(r"<[^>]+>", "", text).replace("&nbsp;", " ").strip()

def _normalise_text(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())

def _tokenise_query(q: str) -> list[str]:
    # split on whitespace and commas, remove empties
    return [t for t in re.split(r"[\s,]+", (q or "").strip().lower()) if t]


# -----------------------------
# MCP server (DNS rebinding protection disabled)
# This avoids 421 Invalid Host header behind proxies like Azure App Service.
# -----------------------------
mcp = FastMCP(
    "m365_message_centre",
    transport_security=TransportSecuritySettings(
        enable_dns_rebinding_protection=False
    ),
)


# -----------------------------
# Tools
# -----------------------------
@mcp.tool()
async def ping() -> str:
    """Simple health check (no Graph calls)."""
    return "pong"


# -----------------------------
# Message Centre tools 
# -----------------------------

@mcp.tool()
async def get_recent_messages(days: int = 30, top: int = 50) -> str:
    if days < 1 or days > 365:
        return "days must be between 1 and 365."

    dt = _utc_iso_z(datetime.now(timezone.utc) - timedelta(days=days))
    filter_query = f"lastModifiedDateTime ge {dt}"
    params = {"$top": max(1, min(top, 200)), "$filter": filter_query}

    data = await _graph_get(MESSAGES_URL, params=params)
    messages = data.get("value", [])

    lines = []
    for msg in messages[:10]:
        lines.append(
            f"- {msg.get('title', 'Untitled')}\n"
            f"  - ID: {msg.get('id', 'N/A')}\n"
            f"  - Category: {msg.get('category', 'N/A')}\n"
            f"  - Last updated: {msg.get('lastModifiedDateTime', 'N/A')}"
        )
    return _format_list(f"Found {len(messages)} message centre posts.", lines)


@mcp.tool()
async def search_messages(keyword: str, top: int = 50) -> str:
    keyword = (keyword or "").strip()
    if not keyword:
        return "keyword cannot be empty."

    filter_query = f"contains(title, '{_odata_escape(keyword)}')"
    params = {"$top": max(1, min(top, 200)), "$filter": filter_query}

    data = await _graph_get(MESSAGES_URL, params=params)
    messages = data.get("value", [])

    lines = []
    for msg in messages[:10]:
        lines.append(
            f"- {msg.get('title', 'Untitled')}\n"
            f"  - ID: {msg.get('id', 'N/A')}\n"
            f"  - Last updated: {msg.get('lastModifiedDateTime', 'N/A')}"
        )
    return _format_list(f"Found {len(messages)} posts matching '{keyword}'.", lines)


def _looks_like_mc_id(value: str) -> bool:
    return bool(re.fullmatch(r"MC\d{6,}", (value or "").strip(), re.IGNORECASE))

@mcp.tool()
async def get_message_by_id(message_id: str) -> str:
    message_id = (message_id or "").strip().upper()
    if not _looks_like_mc_id(message_id):
        return "message_id must look like MC123456."

    data = await _graph_get(f"{MESSAGES_URL}/{message_id}")
    # This endpoint returns a single object, not { "value": [...] }
    msg = data

    lines = [
        f"- {msg.get('title', 'Untitled')}",
        f"  - ID: {msg.get('id', 'N/A')}",
        f"  - Category: {msg.get('category', 'N/A')}",
        f"  - Last updated: {msg.get('lastModifiedDateTime', 'N/A')}",
    ]
    return _format_list("Found 1 message centre post.", lines)

@mcp.tool()
async def search_message_center_by_service(
    service_query: str,
    top: int = 25,
    include_title: bool = True,
    days: int = 0,
) -> str:
    """
    Fuzzy search Message Center posts by service name (services[]).
    - service_query: e.g., "copilot", "sharepoint", "microsoft teams"
    - include_title: also match on title text
    - days: if > 0, limits to messages modified in the last N days (client-side)
    """
    service_query = (service_query or "").strip()
    if not service_query:
        return "service_query cannot be empty."

    top = max(1, min(top, 200))
    days = max(0, min(days, 365))

    # Pull a decent chunk; then filter client-side (reliable fuzzy behaviour).
    params = {
        "$top": 200,
        "$orderby": "lastModifiedDateTime desc",
        "$select": "id,title,lastModifiedDateTime,services,category,severity",
    }

    messages = await _graph_get_all_pages(MESSAGES_URL, params=params)

    tokens = _tokenise_query(service_query)

    # Optional client-side "last N days" filter (keeps it simple and robust)
    cutoff = None
    if days > 0:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)

    matches: list[dict[str, Any]] = []
    for m in messages:
        svc_list = m.get("services", []) or []
        svc_text = _normalise_text(" ".join(svc_list))
        title_text = _normalise_text(m.get("title", ""))

        haystack = svc_text + (" " + title_text if include_title else "")

        # token-based fuzzy match: all tokens must appear somewhere
        if all(t in haystack for t in tokens):
            if cutoff:
                lm = m.get("lastModifiedDateTime")
                try:
                    lm_dt = datetime.fromisoformat(lm.replace("Z", "+00:00")) if lm else None
                except Exception:
                    lm_dt = None
                if lm_dt and lm_dt < cutoff:
                    continue

            matches.append(m)

    lines: list[str] = []
    for msg in matches[:min(len(matches), 25)]:
        services = msg.get("services", []) or []
        lines.append(
            f"- {msg.get('title','Untitled')}\n"
            f"  - ID: {msg.get('id','N/A')}\n"
            f"  - Services: {', '.join(services) if services else 'N/A'}\n"
            f"  - Category: {msg.get('category','N/A')}\n"
            f"  - Severity: {msg.get('severity','N/A')}\n"
            f"  - Last updated: {msg.get('lastModifiedDateTime','N/A')}"
        )

    return _format_list(
        f"Found {len(matches)} Message Center post(s) matching service_query '{service_query}'.",
        lines[:top],
    )



# -----------------------------
# Service Health tools 
# -----------------------------

@mcp.tool()
async def get_service_health_overview() -> str:
    data = await _graph_get(HEALTH_OVERVIEWS_URL)
    overviews = data.get("value", [])
    lines = [f"- {o.get('service','Unknown')}: {o.get('status','Unknown')}" for o in overviews]
    return _format_list(f"Found {len(overviews)} service health overviews.", lines)


#@mcp.tool()
#async def get_service_health_issues(top: int = 25) -> str:
#    params = {"$top": max(1, min(top, 200))}
#    data = await _graph_get(ISSUES_URL, params=params)
#    issues = data.get("value", [])
#    lines = []
#    for i in issues[:min(top, 25)]:
#        lines.append(
#            f"- {i.get('title','Untitled')}\n"
#            f"  - ID: {i.get('id','N/A')}\n"
#            f"  - Service: {i.get('service','N/A')}\n"
#            f"  - Status: {i.get('status','N/A')}\n"
#            f"  - Last updated: {i.get('lastModifiedDateTime','N/A')}"
#        )
#    return _format_list(f"Found {len(issues)} service issues.", lines)


@mcp.tool()
async def get_service_health_issue_posts(issue_id: str, top_posts: int = 10) -> str:
    """
    Fetch and display the posts/updates for a specific service health issue.
    Example issue IDs look like: EX226792, MO123456, etc. 
    """
    issue_id = (issue_id or "").strip()
    if not issue_id:
        return "issue_id cannot be empty."

    # Pull the issue including posts. The issues API supports OData query params like $select.
    params = {
        "$select": "id,title,service,status,lastModifiedDateTime,posts"
    }

    data = await _graph_get(f"{ISSUES_URL}/{issue_id}", params=params)

    title = data.get("title", "Untitled")
    service = data.get("service", "N/A")
    status = data.get("status", "N/A")
    last_updated = data.get("lastModifiedDateTime", "N/A")

    posts = data.get("posts", []) or []
    if not posts:
        header = (
            f"Issue: {title}\n"
            f"Service: {service}\n"
            f"Status: {status}\n"
            f"Last updated: {last_updated}\n"
        )
        return _format_list(header, ["No posts found on this issue."])

    # Sort newest-first (some responses may not be ordered)
    posts_sorted = sorted(
        posts,
        key=lambda p: p.get("createdDateTime", ""),
        reverse=True
    )

    top_posts = max(1, min(top_posts, 50))
    lines = []
    for p in posts_sorted[:top_posts]:
        created = p.get("createdDateTime", "N/A")
        post_type = p.get("postType", "N/A")

        desc = p.get("description", {}) or {}
        content = desc.get("content", "") or ""
        content_type = desc.get("contentType", "N/A")

        # If content is HTML, strip it lightly for readability
        printable = _strip_html(content) if content_type.lower() == "html" else (content.strip() if content else "")

        # Keep it short in the response
        if len(printable) > 800:
            printable = printable[:800] + "…"

        lines.append(
            f"- [{created}] ({post_type})\n"
            f"  - {printable if printable else 'No description content.'}"
        )

    header = (
        f"Issue: {title}\n"
        f"Service: {service}\n"
        f"Status: {status}\n"
        f"Last updated: {last_updated}\n"
        f"Posts returned: {len(posts)} (showing top {min(top_posts, len(posts))})"
    )
    return _format_list(header, lines)


@mcp.tool()
async def search_service_health_issues(
    service_query: str = "",
    issue_id: str = "",
    top: int = 25,
    include_title: bool = True,
) -> str:
    """
    Search service health issues by:
    - issue_id (exact), and/or
    - service_query (fuzzy, token-based match against the 'service' field),
      and optionally title.

    This uses client-side fuzzy matching after retrieving issues. The issues endpoint
    supports OData query params like $top and $orderby. [1](https://learn.microsoft.com/en-us/graph/api/serviceannouncement-list-issues?view=graph-rest-1.0)
    """
    issue_id = (issue_id or "").strip().upper()
    service_query = (service_query or "").strip()
    top = max(1, min(top, 200))

    # --- 1) Exact lookup by issue id (if provided)
    if issue_id:
        try:
            issue = await _graph_get(f"{ISSUES_URL}/{issue_id}")
        except httpx.HTTPStatusError as e:
            code = getattr(e.response, "status_code", "unknown")
            return f"No issue found for issue_id '{issue_id}'. HTTP status: {code}"

        # If service_query also supplied, validate it fuzzily against returned issue
        if service_query:
            tokens = _tokenise_query(service_query)
            svc = _normalise_text(issue.get("service", ""))
            ttl = _normalise_text(issue.get("title", ""))

            haystack = svc + (" " + ttl if include_title else "")
            if not all(t in haystack for t in tokens):
                return _format_list(
                    f"Issue '{issue_id}' found, but it does not match service_query '{service_query}'.",
                    [
                        f"- Title: {issue.get('title','Untitled')}",
                        f"  - Service: {issue.get('service','N/A')}",
                        f"  - Status: {issue.get('status','N/A')}",
                        f"  - Last updated: {issue.get('lastModifiedDateTime','N/A')}",
                    ],
                )

        return _format_list(
            "Found 1 matching service health issue.",
            [
                f"- {issue.get('title','Untitled')}\n"
                f"  - ID: {issue.get('id','N/A')}\n"
                f"  - Service: {issue.get('service','N/A')}\n"
                f"  - Status: {issue.get('status','N/A')}\n"
                f"  - Last updated: {issue.get('lastModifiedDateTime','N/A')}"
            ],
        )

    # --- 2) Fuzzy search by service_query (required if no issue_id)
    if not service_query:
        return "Please provide at least one of: service_query, or, issue_id."

    # Pull issues (you can raise $top if you want, but your tenant is small right now)
    params = {
        "$top": 200,
        "$orderby": "lastModifiedDateTime desc",
        "$select": "id,title,service,status,lastModifiedDateTime",
    }
    data = await _graph_get(ISSUES_URL, params=params)
    issues = data.get("value", []) or []

    tokens = _tokenise_query(service_query)

    # Token-based fuzzy match:
    # - All tokens must appear in service name (and optionally title)
    matches: list[dict[str, Any]] = []
    for i in issues:
        svc = _normalise_text(i.get("service", ""))
        ttl = _normalise_text(i.get("title", ""))
        haystack = svc + (" " + ttl if include_title else "")
        if all(t in haystack for t in tokens):
            matches.append(i)

    # Format output
    lines = []
    for i in matches[:min(len(matches), 25)]:
        lines.append(
            f"- {i.get('title','Untitled')}\n"
            f"  - ID: {i.get('id','N/A')}\n"
            f"  - Service: {i.get('service','N/A')}\n"
            f"  - Status: {i.get('status','N/A')}\n"
            f"  - Last updated: {i.get('lastModifiedDateTime','N/A')}"
        )

    return _format_list(
        f"Found {len(matches)} issue(s) matching fuzzy service_query '{service_query}'.",
        lines[:top],
    )

# -----------------------------
# Run (App Service friendly) 
# -----------------------------
def main() -> None:
    port = int(os.environ.get("PORT", os.environ.get("WEBSITES_PORT", "8000")))
    logger.info("Starting MCP HTTP server on 0.0.0.0:%s", port)

    # FastMCP build rejects host= in run(); set via settings instead. 
    mcp.settings.host = "0.0.0.0"
    mcp.settings.port = port

    mcp.run(transport="streamable-http")


if __name__ == "__main__":
    main()